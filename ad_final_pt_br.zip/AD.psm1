﻿function ad {

<#
    .SYNOPSIS
    AD is an advanced Powershell function. It gives you a menu of powerful Active Directory commands.

    .NOTES
    Author: Patrick Gruenauer, MVP PowerShell
    Web: https://sid-500.com

    .LINK
    None.

    .INPUTS
    None.

    .OUTPUTS
    None.
  #>

$host.ui.RawUI.WindowTitle='Created by SID-500.COM | Patrick Gruenauer | Traduzido para português Brasil por Gabriel Luiz - gabrielluiz.com'

$bufferSize = $Host.UI.RawUI.BufferSize
$buffersize.Height = 500
$host.UI.RawUI.BufferSize = $buffersize
 
$WindowSize = $host.UI.RawUI.WindowSize
$WindowSize.Height = 45
$host.UI.RawUI.WindowSize = $WindowSize


$line='========================================================='
$line2='________________________________________________________'


if (Get-Module -ListAvailable -Name ActiveDirectory) {
    Import-Module ActiveDirectory
} else {
    ''
    Write-Host "Operação abortada. Nenhum módulo do Active Directory encontrado. Execute esta ferramenta em um controlador de domínio." -ForegroundColor Red
    ''
    throw "-Erro"
}

cls

do {

$line
Write-Host ' ACTIVE DIRECTORY Domain Services Section (v 1.1) - Construido por Patrick Gruenauer MVP - sid-500.com' -ForegroundColor Yellow
Write-Host ' Traduzido para Português Brasil por Gabriel Luiz MVP - gabrielluiz.com' -ForegroundColor Green
$line
Write-Host '---------------------------------------------------------'
Write-Host '           Floresta | Domínio | Controlador de Domínio' -ForegroundColor Yellow
Write-Host '---------------------------------------------------------'
Write-Host " 1 - Floresta | Domínio | Configuração de Sites ($env:userdnsdomain)"
Write-Host ' 2 - Lista contoladores de domínios'
Write-Host ' 3 - Replicar todos os controladores de domínio'
Write-Host ' 4 - Mostra a política de senha padrão do domínio'
Write-Host ' 5 - Lista todos os administradores do domínio'
Write-Host ' 6 - Lista todas as GPOs ativas'
Write-Host '---------------------------------------------------------'
Write-Host '                 Usuário | Computador | Grupos' -ForegroundColor Yellow
Write-Host '---------------------------------------------------------'
Write-Host ' 7 - Lista dos os sistemas operacionais Windows Cliente (Exemplo: Windows 10 Pro)'
Write-Host ' 8 - Lista dos os sistemas operacionais Windows Server (Exemplo: Windows Server 2012 R2)'
Write-Host ' 9 - Lista todos os computadores (por sistema operacional)'
Write-Host '10 - Executar systeminfo em computadores remotos'
Write-Host '11 - Mova o computador para OU específica'
Write-Host '12 - Lista todos os grupos'
Write-Host '13 - Listar membros do grupo por usuário'
Write-Host '14 - Listar todos os usuários (ativados)'
Write-Host '15 - Listar as propriedades do usuário'
Write-Host '16 - Verifica em qual controlador de domínio o usuário fez a requisição de fazer login no domínio'
Write-Host '17 - Mostrar Usuário conectado no momento por computador'
Write-Host '18 - Enviar mensagem para a área de trabalho dos usuários'
Write-Host '19 - Encontre contas de usuário ou computador órfãos'
Write-Host '20 - Configurar associação de grupo com base no tempo'
Write-Host '---------------------------------------------------------'
Write-Host '                Criação de usuários | Desativar usuários' -ForegroundColor Yellow
Write-Host '---------------------------------------------------------'
Write-Host '21 - Crie um novo usuário do AD (Com base em um usuário já existente)'
Write-Host '22 - Desabilitar um usuário do AD'
Write-Host '0  - Sair' -ForegroundColor Red

Write-Host ''

$input=Read-Host 'Selecionar'

switch ($input) 
 { 
 1 {
    

    ''
    Write-Host -ForegroundColor Green 'Configuração da Floresta' 

    $get=Get-ADForest
    $forest+=New-Object -TypeName PSObject -Property ([ordered]@{

    'Root Domain'=$get.RootDomain
    'Forest Mode'=$get.ForestMode
    'Domains'=$get.Domains -join ','
    'Sites'=$get.Sites -join ','
    })
   
    $forest | Format-Table -AutoSize -Wrap
    
    
    Write-Host -ForegroundColor Green 'Configuração do Domínio' 
     
    Get-ADDomain | Format-Table DNSRoot, DomainMode, ComputersContainer, DomainSID -AutoSize -Wrap

    Write-Host -ForegroundColor Green 'Configuração dos Sites'
        
        $GetSite = [System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest().Sites
        $Sites = @()
        foreach ($Site in $GetSite) {
        $Sites += New-Object -TypeName PSObject -Property (
        @{
        'SiteName'  = $site.Name
        'SubNets' = $site.Subnets -Join ','
        'Servers' = $Site.Servers -Join ','
        }
        )
        }
        $Sites | Format-Table -AutoSize -Wrap
        
    
    Write-Host -ForegroundColor Green 'Recursos opcionais Habilitados' 
    Get-ADOptionalFeature -Filter * | Format-Table Name,RequiredDomainMode,RequiredForestMode -AutoSize -Wrap
    
    Read-Host 'Pressione 0 e Enter para continuar'
	
    } 
    
    

 2 {
    $dcs=Get-ADDomainController -Filter * 
    $dccount=$dcs | Measure-Object | Select-Object -ExpandProperty count
    ''
    Write-Host -ForegroundColor Green "Serviços de Domínio do Active Directory ($env:userdnsdomain)" 
   
    
    $domdc=@()

    foreach ($dc in $dcs) {
    $domdc += New-Object -TypeName PSObject -Property (

    [ordered]@{
    'Name' = $dc.Name
    'IP Address' = $dc.IPv4Address
    'OS' = $dc.OperatingSystem
    'Site' = $dc.Site
    'Global Catalog' = $dc.IsGlobalCatalog
    'FSMO Roles' = $dc.OperationMasterRoles -join ','
    }
    )
    }
    ''
    
    $domdc | Format-Table -AutoSize -Wrap

    
    Write-Host 'Número total: '$dccount"" -ForegroundColor Yellow

    ''
	
    $ping=Read-Host "Deseja testar a conectividade (ping) para esses controladores de domínio? (S/N)?"

    If ($ping -eq 'S') {
	foreach ($items in $dcs.Name) {
	Test-Connection $items -Count 1 | Format-Table Address, IPv4Address, ReplySize, ResponseTime}
    Read-Host 'Pressione 0 e Enter para continuar'
    }
    
    else {
    ''
    Read-Host 'Pressione 0 e Enter para continuar'
    }

    }

 3 { 
    ''
    Write-Host "Este sub-menu replica todos os controladores de domínio em todos os sites do domínio $env:userdnsdomain."
    ''

    Write-Host 'Iniciar a replicação?' -ForegroundColor Yellow
    ''
    $startr=Read-Host 'S/N coloque S para Sim e N para Não.'

    If ($startr) 

    {

    (Get-ADDomainController -Filter *).Name | Foreach-Object {repadmin /syncall $_ (Get-ADDomain).DistinguishedName /e /A | Out-Null}; Start-Sleep 10; Get-ADReplicationPartnerMetadata -Target "$env:userdnsdomain" -Scope Domain | Select-Object Server, LastReplicationSuccess | Out-Host


    }


    }
 
 4 {
    ''
     Write-Host -ForegroundColor Green 'A Diretiva de Domínio Padrão está configurada da seguinte maneira:'`n 
     Get-ADDefaultDomainPasswordPolicy | Format-List ComplexityEnabled, LockoutDuration,LockoutObservationWindow,LockoutThreshold,MaxPasswordAge,MinPasswordAge,MinPasswordLength,PasswordHistoryCount,ReversibleEncryptionEnabled
     
     Read-Host 'Pressione 0 e Enter para continuar' 
    
    } 


5 {

    ''
    Write-Host -ForegroundColor Green 'Os seguintes usuários são membros do grupo Administradores de Domínio - Os seguintes usuários são membros do grupo Administrador do Domínio:'`n

    $sid=(Get-ADDomain).DomainSid.Value + '-512'
    Get-ADGroupMember -identity $sid | Format-Table Name,SamAccountName,SID -AutoSize -Wrap
    ''
    Read-Host 'Pressione 0 e Enter para continuar'
    
    } 

6 {
    ''
    Write-Host -ForegroundColor Green 'Os GPOs abaixo estão vinculados aos objetos do AD:'`n 
    Get-GPO -All | ForEach-Object {
    If ( $_ | Get-GPOReport -ReportType XML | Select-String '<LinksTo>' ) {
    Write-Host $_.DisplayName}}
    ''
    Read-Host 'Pressione 0 e Enter para continuar'


    }

 
 7 {
    $client=Get-ADComputer -Filter {operatingsystem -notlike '*server*'} -Properties Name,Operatingsystem,OperatingSystemVersion,IPv4Address 
    $ccount=$client | Measure-Object | Select-Object -ExpandProperty count
    ''
    Write-Host -ForegroundColor Green "Windows Clients $env:userdnsdomain"
    
    Write-Output $client | Sort-Object Operatingsystem | Format-Table Name,Operatingsystem,OperatingSystemVersion,IPv4Address -AutoSize
    ''
    Write-Host 'Total: '$ccount"" -ForegroundColor Yellow
    ''
    Read-Host 'Pressione 0 e Enter para continuar'
    }
 
 8 {
    $server=Get-ADComputer -Filter {operatingsystem -like '*server*'} -Properties Name,Operatingsystem,OperatingSystemVersion,IPv4Address 
    $scount=$server | Measure-Object | Select-Object -ExpandProperty count
    ''
    Write-Host -ForegroundColor Green "Windows Server $env:userdnsdomain" 
   
    Write-Output $server | Sort-Object Operatingsystem | Format-Table Name,Operatingsystem,OperatingSystemVersion,IPv4Address
    ''
    Write-Host 'Total: '$scount"" -ForegroundColor Yellow
    ''
    Read-Host 'Pressione 0 e Enter para continuar'
    }
 
 9 {
    $all=Get-ADComputer -Filter * -Properties Name,Operatingsystem,OperatingSystemVersion,IPv4Address 
    $acount=$all | Measure-Object | Select-Object -ExpandProperty count
    ''
    Write-Host -ForegroundColor Green "All Computer $env:userdnsdomain" 
     
    Write-Output $all | Select-Object Name,Operatingsystem,OperatingSystemVersion,IPv4Address | Sort-Object OperatingSystem | Format-Table -GroupBy OperatingSystem 
    Write-Host 'Total: '$acount"" -ForegroundColor Yellow
    ''
    Read-Host 'Pressione 0 e Enter para continuar'
    }

 10  {    do {

        Write-Host ''
        Write-Host 'Isso executa informações do sistema em computadores específicos. Selecionar escopo:' -ForegroundColor Green
        Write-Host ''
        Write-Host '1 - Computador local' -ForegroundColor Yellow
        Write-Host '2 - Computador remoto (Digite o nome do computador) hostname' -ForegroundColor Yellow
        Write-Host '3 - Todos os Windows Server (Exemplo: Windows Server 2012 R2)' -ForegroundColor Yellow
        Write-Host '4 - Todos os Windows Cliente (Exemplo: Windows 10 Pro)' -ForegroundColor Yellow
        Write-Host '0 - Sair' -ForegroundColor Yellow
        Write-Host ''
        $scopesi=Read-Host 'Selecione'
        
        $header='Nome do computador','Sistema Operacional','Versão','Fabricante','Configuração','Tipo de compilação','Proprietário registrado','Organização registrada','ID do produto','Data da instalação','Tempo de inicialização','Fabricante do sistema','Modelo','Tipo','Processador','Bios','Windows Directory','Diretório de instalação do Windows','Dispositivo de iniciaçâo','Idioma','Teclado','Fuso horário','Total de memória física','Memória física disponível','Virtual Memory','Memória virtual disponível','Memória virtual em uso','Arquivo de paginação','Domínio','Servidor de Logon','Hotfix','Placa de rede','Hyper-V'


        switch ($scopesi) {

        1 {
            
            & "$env:windir\system32\systeminfo.exe" /FO CSV | Select-Object -Skip 1 | ConvertFrom-Csv -Header $header | Out-Host
            
          }

        2 {
            ''
            Write-Host 'Separe vários nomes de computadores por vírgula. (exemplo: server01,server02)' -ForegroundColor Yellow
            Write-Host ''
            $comps=Read-Host 'Digite o Nome do Computador (Hostname)'
            $comp=$comps.Split(',')

            $cred=Get-Credential -Message 'Digite o nome de usuário e a senha de um membro do grupo de administradores de domínio'
            Invoke-Command -ComputerName $comps -Credential $cred {systeminfo /FO CSV | Select-Object -Skip 1} -ErrorAction SilentlyContinue | ConvertFrom-Csv -Header $header | Out-Host
            

            }

        3 { 
            $cred=Get-Credential -Message 'Digite o nome de usuário e a senha de um membro do grupo de administradores de domínio'

            Invoke-Command -ComputerName (Get-ADComputer -Filter {operatingsystem -like '*server*'}).Name -Credential $cred {systeminfo /FO CSV | Select-Object -Skip 1} -ErrorAction SilentlyContinue | ConvertFrom-Csv -Header $header | Out-Host
            
            }

        4 {
            $cred=Get-Credential -Message 'Digite o nome de usuário e a senha de um membro do grupo de administradores de domínio'

            Invoke-Command -ComputerName (Get-ADComputer -Filter *).Name -Credential $cred {systeminfo /FO CSV | Select-Object -Skip 1} -ErrorAction SilentlyContinue | ConvertFrom-Csv -Header $header | Out-Host
            
            }

            }  
            
            }
        while ($scopesi -ne '0')
            }
                     
      
 
 11 {
        ''
    Write-Host 'Esta seção move as Contas de computador para uma UO.' -ForegroundColor Green

    do {
     
     ''
     Write-Host 'Digite o Nome do Computador (Hostname) ou S para sair' -ForegroundColor Yellow
     ''
     $comp=Read-Host 'Nome do computador (Hostname)'

     $c=Get-ADComputer -Filter 'name -like $comp' -Properties CanonicalName -ErrorAction SilentlyContinue

     $cfound=$c.Name
     
     If ($comp -eq 'S') {Break}
     
     If ($cfound)
     
     {

     $discfound=$c.CanonicalName

     ''
     Write-host -foregroundcolor Green "$comp in $discfound encontrado!"
     ''
     
     }

    elseif (!$cfound) {
    ''
    Write-Host -ForegroundColor Red "$comp não encontrado. Por favor, tente novamente."}
    

    
   }
   
   while (!$cfound)

    do {


     If (($comp -eq 'S') -or (!$cfound)) {Break}

     $Domain=(Get-ADDomain).DistinguishedName

     Write-Host 'Digite o nome da UO (por exemplo, RH) ou S para sair' -ForegroundColor Yellow
     ''
     
     $OU=Read-Host 'Digite o nome da OU'

     $OUfound=Get-ADOrganizationalUnit -Filter 'name -like $OU'
     
     If ($OU -eq 'S') {Break}
     
     If ($OUfound)
     
     {
     ''
     Write-host -foregroundcolor Green "$OUfound encontrado!"
     ''
     }

    elseif (!$OUfound) {
    ''
    Write-Host -ForegroundColor Red "$OU não encontrado. Por favor, tente novamente."
    ''
    
    }
     }
   
   
   while (!$OUfound)

    If ($comp -eq 'S') {Break}

    If ($OUfound -and $cfound) 

                {
        ''
        Write-Host "Tem certeza de que deseja mover o Computador $cfound to $OUfound ?" -ForegroundColor Yellow
        ''
        $dec=Read-Host "Pressione S ou qualquer outra tecla para abortar"}

    If ($dec -eq "S")

            {

            $dis=$OUfound.DistinguishedName

            Get-ADComputer $cfound | Move-ADObject -TargetPath "$dis"

            ''

            Write-Host "Computer $cfound moved to $OUfound" -ForegroundColor Green

            ''

            Get-ADComputer -Identity $cfound | Select-Object Name,DistinguishedName,Enabled,SID | Out-Host


            }

else 

{
''
Write-Host 'Operação abortada.' -ForegroundColor Red
}
''
Read-Host 'Pressione 0 e Enter para continuar'

    }
    
 
 12 {
    ''
        Write-Host 'Visão geral de todos os grupos do Active Directory' -ForegroundColor Green
        Get-ADGroup -Filter * -Properties * | Sort-Object Name | Format-Table Name,GroupCategory,GroupScope,SID -AutoSize -Wrap | more
        Read-Host 'Pressione 0 e Enter para continuar'
    }

 13 {
        do {
        ''
        $groupm=Read-Host 'Digite o nome do grupo'
        ''
        Write-Host "Membros do grupo de $groupm" -ForegroundColor Green
        Get-ADGroupMember $groupm | Format-Table Name,SamAccountName,SID -AutoSize -Wrap
        $input=Read-Host 'Sair da pesquisa de grupos? (S/N)'
        }
        while ($input -eq 'N')
    }
 
 14 { 
        ''
        Write-Host "Os seguintes usuários em $env:userdnsdomain estão ativados:" -ForegroundColor Green
        Get-ADUser -Filter {enabled -eq $true} -Properties CanonicalName,whenCreated | Sort-Object Name | Format-Table Name,SamAccountName,CanonicalName,whenCreated -AutoSize -wrap | more
        Read-Host 'Pressione 0 e Enter para continuar'
     
     } 
 


 15 {
        do {
        ''
        $userp=Read-Host 'Digite o nome de logon do usuário'
        ''
        Write-Host "Detalhes do usuário $userp" -ForegroundColor Green
        
        Get-ADUser $userp -Properties * | Format-List GivenName,SurName,DistinguishedName,Enabled,EmailAddress,ProfilePath,ScriptPath,MemberOf,LastLogonDate,whencreated
        $input=Read-Host 'Parar de procurar usuários? (S/N)'
        }
        while ($input -eq 'N')
        
        }

 16 {   ''
        Write-Host "Esta seção mostra o logon mais recente do Active Directory dos usuários, com base em todos os controladores de domínio de $env:userdnsdomain." -ForegroundColor Green
        

        do {

        do {
        ''
        Write-Host 'Digite o NOME DE LOGON DO USUÁRIO (S para Sair)' -ForegroundColor Yellow
        ''
        $userl=Read-Host 'NOME DE LOGON DO USUÁRIO'
        
        If ($userl -eq 'S') {Break}
        
        $ds=dsquery user -samid $userl

        ''

        If ($ds)

        {

        Write-Host "User $userl encontrado! Aguarde ... entrando em contato com todos os controladores de domínio ... Mostrando resultados da maioria dos controladores de domínio atuais ..." -ForegroundColor Green

        }

        else 

        {


        Write-Host "User $userl não encontrado. Tente novamente" -ForegroundColor Red}
        
        }

        while (!$ds)
 
        $resultlogon=@()

        If ($userl -eq 'S') {Break}

        $getdc=(Get-ADDomainController -Filter *).Name

        foreach ($dc in $getdc) {

        Try {
        
        $user=Get-ADUser $userl -Server $dc -Properties lastlogon -ErrorAction Stop
        
        $resultlogon+=New-Object -TypeName PSObject -Property ([ordered]@{
                
                'DC mais atual' = $dc
                'Usuário' = $user.Name
                'Último login' = [datetime]::FromFileTime($user.'lastLogon')
                
                })
        
        }

        Catch {
        ''
        Write-Host "Nenhum relatório de $dc!" -ForegroundColor Red

        }

        }
        
        

        If ($userl -eq 'S') {Break}
        ''

        $resultlogon | Where-Object {$_.lastlogon -NotLike '*1601*'} | Sort-Object LastLogon -Descending | Select-Object -First 1 | Format-Table -AutoSize

        If (($resultlogon | Where-Object {$_.lastlogon -NotLike '*1601*'}) -EQ $null)

        {
        
        ''
        Write-Host "Todos os controladores de domínio informam que o usuário"$user.name"nunca fez logon até agora." -ForegroundColor Red}
        
        Write-Host 'Procure denovo? Pressione S ou qualquer outra tecla para sair ' -ForegroundColor Yellow
        ''
        $input=Read-Host 'Digite (S/N)'    
        


}

while ($input -eq 'S')


}


 17 {    $result=@()

       ''
       Write-Warning 'Esta seção só funciona perfeitamente nos sistemas operacionais em inglês.'

       ''

       $read=Read-Host 'Digite NOME DO COMPUTADOR (Hostname) para consultar usuários conectados'

       $cred=Get-Credential -Message 'Digite o nome de usuário e a senha de um membro do grupo de administradores de domínio (domínio / nome de usuário)'

       Invoke-Command -ComputerName $read -ScriptBlock {quser} -Credential $cred | Select-Object -Skip 1 | Foreach-Object {

       $b=$_.trim() -replace '\s+',' ' -replace '>','' -split '\s'


       If (($b[2] -like 'Disc*') -or ($b[2] -like 'Getr*')) {

          $result+= New-Object -TypeName PSObject -Property ([ordered]@{
                'Usuário' = $b[0]
                'Computador' = $read
                'Data' = $b[4]
                'Hora' = $b[5..6] -join ' '
                })
           
            
            }

        else {

        $result+= New-Object -TypeName PSObject -Property ([ordered]@{
                'Usuário' = $b[0]
                'Computador' = $read
                'Data' = $b[5]
                'Hora' = $b[6..7] -join ' '
                })

                }

        

} 
         ''
         Write-Host "Logins de usuários ativados $read" -ForegroundColor Green

         $result | Format-Table

         Read-Host 'Pressione 0 e Enter para continuar'
        }


 18 {    do {
        Write-Host ''
        Write-Host 'Para quais computadores uma mensagem deve ser enviada?'
        Write-Host ''
        Write-Host '1 - Computador local - Localhost' -ForegroundColor Yellow
        Write-Host '2 - Computador remoto (Digite o nome do computador - hostname)' -ForegroundColor Yellow
        Write-Host '3 - Todos os Windows Server (Exemplo Windows Server 2016)' -ForegroundColor Yellow
        Write-Host '4 - Todos os Windows Cliente (Exemplo: Windows 10 Pro)' -ForegroundColor Yellow
        Write-Host '0 - Sair' -ForegroundColor Yell
        Write-Host ''
        $scopemsg=Read-Host 'Selecionar'
        
        

        switch ($scopemsg) {

        1 {
            
            ''
            Write-Host 'Digite a mensagem enviada a todos os usuários conectados em Computador local - Localhost' -ForegroundColor Yellow
            ''
            $msg=Read-Host 'Mensagem'
            msg * "$msg"
            
          }

        2 {
            ''
            Write-Host 'Separe vários nomes de computadores por vírgula. (exemplo: server01, server02)' -ForegroundColor Yellow
            ''
            $comp=Read-Host 'Digite o nome do computador - hostname'
            $comps=$comp.Split(',')
            ''
            $msg=Read-Host 'Digite a mensagem'
            $cred=Get-Credential -Message 'Digite o nome de usuário e a senha de um membro do grupo de administradores de domínio'
            Invoke-Command -ComputerName $comps -Credential $cred -ScriptBlock {msg * $using:msg}
            
          } 
            

        3 {
            ''
            
            Write-Host 'Observe que a mensagem será enviada para todos os servidores!' -ForegroundColor Yellow
            ''
            $msg=Read-Host 'Digite a mensagem'
            $cred=Get-Credential -Message 'Digite o nome de usuário e a senha de um membro do grupo de administradores de domínio'

            
            (Get-ADComputer -Filter {operatingsystem -like '*server*'}).Name | Foreach-Object {Invoke-Command -ComputerName $_ -ScriptBlock {msg * $using:msg} -Credential $cred -ErrorAction SilentlyContinue}}
           
         4 { 
            ''
            
            Write-Host 'Observe que a mensagem será enviada para todos os computadores!' -ForegroundColor Yellow
            ''
            $msg=Read-Host 'Digite a mensagem'

            $cred=Get-Credential -Message 'Digite o nome de usuário e a senha de um membro do grupo de administradores de domínio'

            (Get-ADComputer -Filter *).Name | Foreach-Object {Invoke-Command -ComputerName $_ -ScriptBlock {msg * $using:msg} -Credential $cred -ErrorAction SilentlyContinue}}

           
           }}
        
        while ($scopemsg -ne '0')
}

 19 {
    ''
    
    Write-Host 'Digite U para pesquisar contas de USUÁRIO órfãs ou C para contas Computadores ou Q para sair' -ForegroundColor Yellow
    ''
    $orp=Read-Host 'Digite (U/C)'
    If ($orp -eq 'S')

    {Break}

    ''

    Write-Host 'Digite o período em DIAS nos quais USUÁRIOS ou COMPUTADORES não fizeram logon desde hoje. Exemplo: se você inserir 365 dias, o sistema procurará todos os usuários / computadores que não fizeram logon por um ano.' -ForegroundColor Yellow
    ''
    
    $span=Read-Host 'Intervalo de tempo'


    If ($orp -eq 'U') {

    ''

    Write-Host "Os seguintes USUÁRIOS estão ativados e não se conectam há  $span dias:" -ForegroundColor Green

    Get-ADUser -Filter 'enabled -ne $false' -Properties LastLogonDate,whenCreated | Where-Object {$_.lastlogondate -ne $null -and $_.lastlogondate -le ((get-date).adddays(-$span))} | Format-Table Name,SamAccountName,LastLogonDate,whenCreated
    
    Write-Host 'Logins de usuários e computadores são replicados a cada 14 dias. Os dados podem não estar completamente atualizados.' -ForegroundColor Yellow
    ''
    Read-Host 'Pressione 0 e Enter para continuar'
    
    }

    If ($orp -eq 'C') {

    ''

    Write-Host "Os seguintes COMPUTADORES estão ativados e não se conectam há  $span dias:" -ForegroundColor Green

    Get-ADComputer -Filter 'enabled -ne $false' -Properties LastLogonDate,whenCreated | Where-Object {$_.lastlogondate -ne $null -and $_.lastlogondate -le ((get-date).adddays(-$span))} | Format-Table Name,SamAccountName,LastLogonDate,whenCreated
    
    Write-Host 'Logins de usuários e computadores são replicados a cada 14 dias. Os dados podem não estar completamente atualizados.' -ForegroundColor Yellow
    ''
    Read-Host 'Pressione 0 e Enter para continuar'
    
    }
        
}

20 {

    $checkF=(Get-ADForest).ForestMode
    $opt=(Get-ADOptionalFeature -Identity "Privileged Access Management Feature").enabledscopes

    ''

    If (($checkF -like '*2016*') -or ($checkF -like '*2019*') -and ($opt.count -ne '0' ))

    {


    ''

    Write-Host "O modo da floresta é $checkF. Recurso de gerenciamento de acesso privilegiado ativado. Está tudo bem. Se movendo ..." -ForegroundColor Green
    ''
    Write-Host "Esta seção configura a associação ao grupo com base no tempo. Forneça Usuário, Grupo e Período." -ForegroundColor Green
    ''

    do {

    Write-Host 'Digite o nome de usuário para logon no grupo com base no tempo ou pressione S para sair.' -ForegroundColor Yellow
    ''

    $user=Read-Host "Nome de logon do usuário"
    If ($user -eq 'S') {Break}
    $ds=dsquery user -samid $user

    ''

    If ($ds)

    {

    Write-Host "Usuário $user encontrado!" -ForegroundColor Green

    }

    else 

    {


    Write-Host "Usuário $user não encontrado. Tente novamente" -ForegroundColor Red}
    ''
    }

    while (!$ds)

    do {

    If ($user -eq 'S') {Break}

    Write-Host 'Digite o Nome do GRUPO para Associação ao grupo com base no tempo ou pressione S para sair.' -ForegroundColor Yellow
    ''

    $group=Read-Host "Nome do GRUPO"
    If ($group -eq 'S') {Break}
    $dsg=dsquery group -samid $group
    ''
    If ($dsg)

    {

    Write-Host "Grupo $group encontrado!" -ForegroundColor Green

    }

    else 

    {


    Write-Host "Grupo $group não encontrado. Tente novamente" -ForegroundColor Red}
    ''

    

    If ($group -eq 'S')
    {Break}

    }

    while (!$dsg)

    If (($user -eq 'S') -or ($group -eq 'S')) {Break}

    Write-Host 'Digite o intervalo de tempo da associação ao grupo em HORAS ou S para sair' -ForegroundColor Yellow
    ''

    $timegpm=Read-Host 'INTERVALO DE TEMPO'
    If ($timegpm -eq 'S')
    {Break}

    Add-ADGroupMember -Identity "$group" -Members $user -MemberTimeToLive (New-TimeSpan -Hours $timegpm)
    ''
    Write-Host "Aqui está sua configuração:" -ForegroundColor Yellow
    ''
    $groupup=$group.ToUpper()
    Write-Host "Associação de grupo com base no tempo para $groupup" -ForegroundColor Green
    ''
    Get-ADGroup $group -Properties Member -ShowMemberTimeToLive | Select-Object Name -ExpandProperty Member | Where-Object {($_ -like '*TTL*')}
    Write-Host ''
    Read-Host 'Pressione 0 e Enter para continuar'
      }
    
    else 

    {
    ''
    $fname=(Get-ADForest).Name
    Write-Host "Operação abortada." -ForegroundColor Red
    ''
    Write-Host "A floresta $fname não atende aos requisitos mínimos (Windows Server 2016 Nível da Floresta) e/ou o Recurso de Gerenciamento de Acesso Privilegiado não está habilitado. Solução: Atualize todos os controladores de domínio para o Windows Server 2016, depois eleve o Nível da Florestal e ative o Gerenciamento de Acesso Privilegiado." -ForegroundColor Yellow
    ''
    Read-Host 'Pressione 0 e Enter para continuar'
    }

    }

 21 {
    ''
    Write-Host "Este item de menu cria um novo usuário do AD com base em um existente para o domínio $env:userdnsdomain." -ForegroundColor Green
    
    ''
    do {

    Write-Host 'Digite o NOME DE LOGON de um USUÁRIO EXISTENTE para copiar (S para sair)' -ForegroundColor Yellow
    ''
    $nameds = Read-Host "NOME DE LOGON (usuário existente)"

    If ($nameds -eq 'S') {Break}
    
    If (dsquery user -samid $nameds) {
    '' 
    Write-host -ForegroundColor Green "Usuário do AD $nameds encontrado!"}


    elseif ($nameds = "null") {
    ''
    Write-Host "Usuário não encontrado. Por favor, tente novamente." -ForegroundColor Red
    ''}

    }
    while ($nameds -eq "null")

    If ($nameds -eq 'S') {Break}

    $name = Get-AdUser -Identity $nameds -Properties *

    $DN = $name.distinguishedName
    $OldUser = [ADSI]"LDAP://$DN"
    $Parent = $OldUser.Parent
    $OU = [ADSI]$Parent
    $OUDN = $OU.distinguishedName
    Write-Host ''
    Write-Host 'Digite o NOME DO LOGON do NOVO USUÁRIO' -ForegroundColor Yellow
    ''
    $NewUser = Read-Host "NOME DE LOGON (novo usuário)"
    $firstname = Read-Host "Primeiro Nome"
    $Lastname = Read-Host "Segundo Nome"
    $NewName = "$firstname $lastname"
    $domain = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain() 
    $prof = $name.ProfilePath

    ''
    Write-Host "Tem certeza de que deseja criar usuário $firstname $lastname com o nome de logon $newusere copie as propriedades de $nameds to $newuser (S/N)" -ForegroundColor Yellow
    ''
    
    $surely=Read-Host "Digite (S/N)"

    If ($surely -eq 'S')

    {

    New-ADUser -SamAccountName $NewUser -Name $NewName -GivenName $firstname -displayname "$firstname $lastname" -Surname $lastname -Instance $DN -Path "$OUDN" -AccountPassword (Read-Host "Digite a senha para $firstname $lastname" -AsSecureString) –userPrincipalName $NewUser@$domain -Company $name.Company -Department $name.Department -Manager $name.Manager -title $name.Title -Office $name.Office -City $name.city -PostalCode $name.postalcode -Country $name.country -Fax $name.fax -State $name.State -StreetAddress $name.StreetAddress -Enabled $true -ProfilePath ($prof -replace $name.SamAccountName, $NewUser) -HomePage $name.wWWHomePage -ScriptPath $name.ScriptPath
    Set-ADUser -identity $newUser -ChangePasswordAtLogon $true

    ''

    Write-Host "Copiando associações de grupo, caminho do perfil, script de logon e muito mais ..."
   

    $groups = (Get-ADUser –Identity $name –Properties MemberOf).MemberOf
    foreach ($group in $groups) {

    Add-ADGroupMember -Identity $group -Members $NewUser
    }
    ''
    Write-Host 'O seguinte usuário foi criado pela Ferramenta de Seção de Serviços do Active Directory:' -ForegroundColor Green
    
    Get-ADUser $NewUser -Properties * | Format-List GivenName,SurName,CanonicalName,Enabled,ProfilePath,ScriptPath,MemberOf,whencreated
    }

    else {Break}

    Read-Host 'Pressione 0 e Enter para continuar'
}

 22 {

    ''
    Write-Host "Este item de menu desativa um usuário do AD no domínio $env:userdnsdomain." -ForegroundColor Yellow
    
    ''

    do {
     
     $a=Read-Host 'Digite NOME DE LOGON do usuário a ser desativado (S para sair)'
     
     If ($a -eq 'S') {Break}
     
     If (dsquery user -samid $a)
     
     {
     ''
     Write-host -foregroundcolor Green "Usuário do AD $a encontrado!"
     
     }

    elseif ($a = "null") {
    ''
    Write-Host -ForegroundColor Red "Usuário do AD não encontrado. Por favor, tente novamente."
    ''}
     }
     while ($a -eq "null")

    If ($a -eq 'S') {Break}

    
    $det=((Get-ADuser -Identity $a).GivenName + ' ' + (Get-ADUser -Identity $a).SurName)
    
    ''
    Write-Host "Usuário $det será desativado. Você tem certeza?(S/N)" -ForegroundColor Yellow
    ''
    $sure=Read-Host 'Digite (S/N)'

    If ($sure -eq 'S')

    {

    Get-ADUser -Identity "$a" | Set-ADUser -Enabled $false

    ''

    Write-Host -ForegroundColor Green "Usuário $a foi desativado."

    ''

    $b=Read-Host "Deseja remover todas as associações de grupo desse usuário ($a)? (S/N)"

    If ($b -eq 'S') {

    $ADgroups = Get-ADPrincipalGroupMembership -Identity "$a" | where {$_.Name -ne 'Usuários do Domínio' -contains 'Domain Users'}

    If ($ADgroups -ne $null) {Remove-ADPrincipalGroupMembership -Identity "$a" -MemberOf $ADgroups -Confirm:$false -WarningAction SilentlyContinue -ErrorAction Ignore
    }

    }
    
    }

    else {Break}
    ''

    
    Write-Host 'O seguinte usuário foi desativado pela ferramenta de seção de serviços do Active Directory:' -ForegroundColor Green

    Get-ADUser $a -Properties * | Format-List GivenName,SurName,DistinguishedName,Enabled,MemberOf,LastLogonDate,whencreated

    Read-Host 'Pressione 0 e Enter para continuar'
}


}

}

while ($input -ne '0')

}
